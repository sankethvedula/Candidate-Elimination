Compilation command:

$g++ candidate_elimination.cpp

Run:

$$./a.out
